package modele.entities;

/**
 * The Jour enum which represents the day of the week
 * @author Groupe 4B2
 */
public enum Jour {
    Lundi, Mardi, Mercredi, Jeudi, Vendredi, Samedi, Dimanche
}
