package modele.entities;

/**
 * The Vacances enum which represents the holidays in the data
 * @author Groupe 4B2
 */
public enum Vacances{
    Noel, Ascension, Hiver, Ete, Toussaint, Printemps, Nulle
}
